// ****************************************************************
// Sales.java
//
// Reads in and stores sales for each of 5 salespeople. Displays
// sales entered by salesperson id and total sales for all salespeople.
//
// ****************************************************************
import java.util.Scanner;
public class Sales
{
 public static void main(String[] args)
 {
 //final int SALESPEOPLE = 5;
 //int[] sales = new int[SALESPEOPLE];
 int sum;
 int maxValue, salesNum, minValue, minNum;
 Scanner scan = new Scanner(System.in);
 System.out.println("Please enter the amount of salespeople you want to enter");
 int arrayLength = scan.nextInt();
 int[] sales = new int[arrayLength];
 for (int i=0; i<sales.length; i++)
 {
     int id1 = i+1;
 System.out.print("Enter sales for salesperson " + id1 + ": ");
 sales[i] = scan.nextInt();
 }
 System.out.println("\nSalesperson Sales");
 System.out.println("--------------------");
 sum = 0;
 maxValue = 0;
 salesNum = 0;
  minValue = Integer.MAX_VALUE;
  minNum = 0;
 for (int i=0; i<sales.length; i++)
 {
     int id2 = i+1;
 System.out.println(" " + id2 + " " + sales[i]);
 sum += sales[i];
 if(sales[i]> maxValue){
     maxValue = sales[i];
     salesNum = i+1;
 }
 if(sales[i]< minValue){
     minValue = sales[i];
     minNum = i+1;
 }
 }
 System.out.println("\nTotal sales: " + sum);
 double average =sum/5.00;
 System.out.println("\n Average sales: $" + average);
 System.out.println("\n Salesperson :"+salesNum+" Maximum sales: $" + maxValue);
 System.out.println("\n Salespersom :"+minNum+" Minimum sales: $" + minValue);
 
 System.out.println("Please enter a value");
 int enterValue = scan.nextInt();
 int counter = 0;
 for(int j = 0; j<sales.length; j++){
     int id = j+1;
     if(sales[j]>= enterValue){
        counter++;
        System.out.println("\n ID :"+id+" Sale amount :"+sales[j]);
     }
 }
 System.out.println("Total amount of salespeople that exceeded that amount :"+counter);
 }
}